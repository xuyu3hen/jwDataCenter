// 机务数据中心 Web 端 - 静态服务 + 后端代理
// 用法: node server.js
// 访问: http://localhost:3000

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT || 3000;
const STATIC_DIR = __dirname;
const TARGET_BASE = 'https://10.102.124.50';
const TARGET_PREFIX = '/jwxt';

const origCheck = https.globalAgent.options.checkServerIdentity;
https.globalAgent.options.checkServerIdentity = () => undefined;
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

const MIME = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.mjs': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
};

function serveStatic(req, res, filePath) {
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(500); res.end('Server Error'); return; }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

function proxy(req, res) {
  const parsed = url.parse(req.url);
  const targetPath = parsed.path;

  const options = {
    hostname: '10.102.124.50',
    port: 443,
    path: targetPath,
    method: req.method,
    headers: { ...req.headers, host: '10.102.124.50' },
    rejectUnauthorized: false,
  };

  const proxyReq = https.request(options, (proxyRes) => {
    res.writeHead(proxyRes.statusCode, proxyRes.headers);
    proxyRes.pipe(res);
  });

  proxyReq.on('error', (e) => {
    res.writeHead(502, { 'Content-Type': 'text/plain' });
    res.end('Proxy Error: ' + e.message);
  });

  req.pipe(proxyReq);
}

const server = http.createServer((req, res) => {
  const parsed = url.parse(req.url);
  const pathname = parsed.pathname;

  if (pathname.startsWith(TARGET_PREFIX)) {
    console.log(`[PROXY] ${req.method} ${pathname}`);
    proxy(req, res);
    return;
  }

  let filePath = path.join(STATIC_DIR, pathname);
  if (pathname === '/') filePath = path.join(STATIC_DIR, 'index.html');

  fs.stat(filePath, (err, stat) => {
    if (!err && stat.isFile()) {
      serveStatic(req, res, filePath);
    } else {
      const indexPath = path.join(STATIC_DIR, 'index.html');
      serveStatic(req, res, indexPath);
    }
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`====================================`);
  console.log(`  机务数据中心 Web 端`);
  console.log(`  本地访问: http://localhost:${PORT}`);
  console.log(`  局域网:   http://本机IP:${PORT}`);
  console.log(`  后端代理: ${TARGET_BASE}${TARGET_PREFIX}/...`);
  console.log(`====================================`);
});
